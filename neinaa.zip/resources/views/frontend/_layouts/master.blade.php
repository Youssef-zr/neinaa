@include('frontend._layouts.header')
@yield('content')
@include('frontend._layouts.footer')